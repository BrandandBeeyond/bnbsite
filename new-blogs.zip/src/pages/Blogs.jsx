import React from "react";
import HexCanvas from "../components/hexcanvas/HexCanvas";
import { Link } from "react-router-dom";
import { brandSeriesPosts } from "./Blogs/brandSeriesPosts";

const Blogs = () => {
  const blogs = [
    ...brandSeriesPosts.map((p) => ({
      name: p.title,
      thumbnail: p.hero,
      slug: p.slug,
      blogpara: p.listPara,
      altseo: p.heroAlt,
    })),
    {
  name: "Posting Every Day, Getting No Leads? Here's What Your Marketing Strategy Is Missing",
  thumbnail: "/images/blogs/posting-daily-no-leads-hero.jpg",
  slug: "posting-every-day-getting-no-leads",
  blogpara:
    "Posting daily on social media but not getting enquiries? Discover what your marketing strategy is missing and how a digital marketing agency in Nashik turns posts into real leads.",
  altseo: "digital marketing agency in nashik",
},
{
  name: "AI Is Changing Marketing, But Can It Replace Human Creativity?",
  thumbnail: "/images/blogs/ai-marketing-hero.jpg",
  slug: "ai-changing-marketing-can-it-replace-human-creativity",
  blogpara:
    "AI is transforming digital marketing, but can it replace human creativity? Learn where AI helps, where it falls short, and how the best brands use both.",
  altseo: "AI in digital marketing nashik",
},
    {
      name: "Best Website Design Company in Nashik: Why Businesses Need a High-Converting Website in 2026",
      thumbnail: "/images/website-design.jpg",
      slug: "best-website-design-company-in-nashik",
      blogpara:
        "Discover why the best website design company in Nashik can help your business grow in 2026 with a high-converting, SEO-friendly, mobile-first website.",
      altseo: "best website design company in nashik",
    },
    {
      name: "Why Custom CRM Software Is Mandatory for Your Business in 2026 & How Brand & Beeyond Helps",
      thumbnail: "/images/software-development-herobg.png",
      slug: "why-custom-crm-software-is-mandatory-for-your-business-in-2026",
      blogpara:
        "Learn why custom CRM software development is mandatory in 2026 and how Brand & Beeyond builds CRM software for business growth, automation, and better customer management.",
      altseo: "custom crm software development",
    },
    {
      name: "Best Social Media Marketing Agency in Nashik: How the Right Strategy Can Grow Your Business in 2026",
      thumbnail: "/images/socialmedia1.jpg",
      slug: "best-social-media-marketing-agency-in-nashik",
      blogpara:
        "Discover how the best social media marketing agency in Nashik can grow your business in 2026 with strategy, content, social media management, and paid advertising.",
      altseo: "best social media marketing agency in nashik",
    },
    {
      name: "Why Digital Growth is Essential for Your Business",
      thumbnail: "/images/dm.avif",
      slug: "why-digital-growth-is-essential-for-your-business",
      blogpara:
        "Learn why digital growth is essential for every business and how Brand & Beeyond helps brands grow through websites, SEO, social media, branding, and digital strategy.",
      altseo: "why digital growth is essential for your business",
    },
    {
      name: "How Social Media Marketing Can Increase Your Sales",
      thumbnail: "/images/social-media.jpg",
      slug: "how-social-media-can-increase-your-sales",
      blogpara:
        "Learn how social media marketing helps businesses build brand awareness, generate quality leads, drive website traffic, and increase sales.",
      altseo: "how social media marketing can increase your sales",
    },
    {
      name: "Why Brand and Beeyond is the Top Digital Marketing Agency in Nashik",
      thumbnail: "/images/dm.avif",
      slug: "why-brand-and-beeyond-is-top-digital-marketing-agency-in-nashik",
      blogpara:
        "Discover why Brand and Beeyond is trusted in Nashik for SEO, websites, branding, social media, and complete digital growth solutions.",
      altseo: "top digital marketing agency in nashik",
    },
    {
      name: "Why Custom CRM Software is Essential for Your Business in 2026",
      thumbnail: "/images/webdev2.webp",
      slug: "why-custom-crm-software-is-essential-for-your-business-in-2026",
      blogpara:
        "Discover why custom CRM software is becoming essential for businesses in 2026 and how it improves sales, automation, customer management, and growth.",
      altseo: "custom crm software for business in 2026",
    },
    {
      name: "Social Media Marketing Agency in Nashik | Digital Marketing Services",
      thumbnail: "/images/social-media.jpg",
      slug: "social-media-marketing-agency-in-nashik",
      blogpara:
        "Discover how social media marketing helps businesses build brand awareness, generate quality leads, and increase sales.",
      altseo: "digital marketing strategy for business growth",
    },
    {
      name: "Website Development Company in Nashik | Professional Website Development Services",
      thumbnail: "/images/webdev2.webp",
      slug: "best-website-design-and-development-services-in-nashik",
      blogpara:
        "Looking for a website development company in Nashik? Discover how a professional website can generate leads",
      altseo: "digital marketing strategy for business growth",
    },
    {
      name: "How the Right Digital Marketing Strategy Helps Businesses Grow Faster",
      thumbnail: "/images/dm.avif",
      slug: "right-digital-marketing-strategy-business-growth",
      blogpara:
        "The right digital marketing strategy helps businesses improve visibility, build customer trust, generate quality leads, and create sustainable long-term growth.",
      altseo: "digital marketing strategy for business growth",
    },
    {
      name: "Why Brand and Beeyond is Among the Best Digital Marketing Agencies in Nashik",
      thumbnail: "/images/dm.avif",
      slug: "best-digital-marketing-agency-in-nashik",
      blogpara:
        "Brand and Beeyond is more than another digital marketing agency in Nashik. We build meaningful digital experiences with SEO, websites, branding, and social media strategies that help businesses grow.",
      altseo: "best digital marketing agency in nashik",
    },
    {
      name: "Best Website Design and Development Services in Nashik",
      thumbnail: "/images/website-design.jpg",
      slug: "best-website-design-and-development-services-in-nashik",
      blogpara:
        "Brand and Beeyond delivers website design and development services in Nashik that are responsive, SEO-friendly, and built to support real business growth.",
      altseo: "best website design and development services in nashik",
    },
    {
      name: "From Visibility to Conversions: 360-Degree Digital Marketing | Brand and Beeyond",
      thumbnail: "/images/360marketing.png",
      slug: "best-360-degree-marketing-agency-nashik",
      blogpara:
        " In today’s competitive digital landscape, visibility alone is not enough. Many businesses appear online but still struggle to generate quality leads.",
      altseo: "360 degree marketing agency in nashik",
    },
    {
      name: "How a Well-Developed Website Improves Your SEO and Google Ranking",
      thumbnail: "/images/seo.jpg",
      slug: "best-seo-marketing-agency-in-nashik",
      blogpara:
        " At Brand and Beeyond, we have seen firsthand how businesses start  ranking better simply by fixing their website structure, speed, and design.",
      altseo: "seo marketing agency in nashik",
    },
    {
      name: "Custom Website vs Ready-Made Templates: What’s Best for Your Business?",
      thumbnail: "/images/stratacarebg.png",
      slug: "custom-website-design-company-in-nashik",
      blogpara:
        " Choosing the right website development company is more than a technical decision it’s an emotional investment in the future of your brand. Backed by two years of immersive experience and a portfolio that spans across real estate, hospitality, MSMEs, clinics, startups, and more, we help businesses brand smart, grow fast, and lead with meaning.",
      altseo: "strategic branding in nashik",
    },
    {
      name: "How to Choose the Right Website Development Agency in Nashik & Mumbai",
      thumbnail: "/images/fairytale.png",
      slug: "best-website-development-agencies-mumbai",
      blogpara:
        " Choosing the right website development company is more than a technical decision it’s an emotional investment in the future of your brand. Backed by two years of immersive experience and a portfolio that spans across real estate, hospitality, MSMEs, clinics, startups, and more, we help businesses brand smart, grow fast, and lead with meaning.",
      altseo: "strategic branding in nashik",
    },
    {
      name: "Why Your Business Needs Strategic Branding in 2025",
      thumbnail: "/images/strategic_branding.png",
      slug: "why_your_business_needs_strategic_branding",
      blogpara:
        "  We are not just another branding agency in India. We are a strategic growth partner that builds brands from the inside out—brands that resonate, convert, and sustain. Backed by two years of immersive experience and a portfolio that spans across real estate, hospitality, MSMEs, clinics, startups, and more, we help businesses brand smart, grow fast, and lead with meaning.",
      altseo: "strategic branding in nashik",
    },
    {
      name: "Why Your Business Needs a Strategic Website in 2025",
      thumbnail: "/images/website-design.jpg",
      slug: "why-your-business-needs-strategic-website",
      blogpara:
        " Step into 2025, and you’ll notice one undeniable truth: your website is no longer a “good-to-have,” it’s your digital heartbeat. In a world where attention spans are shrinking and customer choices are multiplying, a website is not just a showcase of your business—it’s the soul of your brand online.",
      altseo: "website design company in nashik",
    },
    {
      name: "The Evolution of Logo Design: Trends to Know in 2025",
      thumbnail: "/images/logodesign.jpg",
      slug: "best-logo-design-trends",
      blogpara:
        " A logo is not just a visual. It is the spirit of a brand, the mark that leaves a memory long after someone has seen it. ",
      altseo: "logo design company in nashik",
    },
  ];

  return (
    <>
      <HexCanvas title={"Blogs"} />

      <section className="printmediapage">
        <div className="container">
          {blogs.map((blg) => (
            <div className="row mt-5" key={blg.slug}>
              <div className="col-lg-6">
                <img
                  src={blg.thumbnail}
                  className="img-fluid object-fit-cover w-100"
                  style={{ maxHeight: "350px" }}
                  alt={blg.altseo}
                />
              </div>
              <div className="col-lg-6">
                <Link className="nav-link" to={`/${blg.slug}`}>
                  <h2 className="foliohead-sm" style={{ color: "#fff" }}>
                    {blg.name}
                  </h2>
                  <div className="blog-para text-white">
                    <p>{blg.blogpara}</p>
                  </div>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default Blogs;
